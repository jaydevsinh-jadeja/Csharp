﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set Consolecolor white=1");
            Console.WriteLine("set Consolecolor Grey=2");
            Console.WriteLine("set Consolecolor Cyan=3");
            Console.WriteLine("set Consolecolor mengata=4");
            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.Clear();
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Cyan;
                    Console.Clear();
                    break;
                case 4:
                    Console.BackgroundColor = ConsoleColor.Magenta;
                    Console.Clear();
                    break;
                default:
                    Console.WriteLine("select 1,2,3,4");
                    break;
            }
            Console.ReadKey();
        }


    }
}
