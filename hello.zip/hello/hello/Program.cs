﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hello
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("hello");
            Console.Read();

        }
    }
}
