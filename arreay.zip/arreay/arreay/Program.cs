﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arreay
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a=new int[3];
            a[0]=1;
            a[1]=2;
            a[2]=3;
            foreach(int i in a)
            {
                Console.Write(i+ " ");

            }Console.Read();
        }
    }
}
