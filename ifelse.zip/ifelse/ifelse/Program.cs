﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ifelse
{
    class Program
    {
        static void Main(string[] args)
        {
             int a;
    a=Convert.ToInt32(Console.ReadLine());                   
    if (a >= 18)
    {
        Console.Write("eligibele");
    }
    else
    {
        Console.WriteLine("not eligible");
    }
    Console.Read();
        }
    }
}
